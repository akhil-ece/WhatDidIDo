#include <stdio.h>
void display(void); // Function prototype
void display(int);
int main()
{
	printf("Inside main\n");
	display(); // Function call
	display(65);
	return 0;
}

// Function Definition
void display(void) // Function Header
{
	printf(" Inside desplay\n");
	return ;
	printf("Second statement\n");
	return;
}
void display(int var)
{
	printf("VAR = %d\n",var);
	return;
}
