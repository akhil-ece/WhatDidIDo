#include <stdio.h>
int gvar = 100;
void display(void);

int main ()
{
	display();
	display();
	display();
	display();
	//printf("svar = %d\n",svar);
	return 0;
}
void display(void)
{
	auto int svar = 10;
	static int svar = 10;

	printf("lvar++ = %d svar++ = %d\n",svar++,svar++);

	return;
}
