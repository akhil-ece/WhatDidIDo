#include <stdio.h>

int main()
{
	int var = 360;

	char* cptr = (char*)&var;

	printf("*cptr = %d\n",*cptr);
	printf("*cptr = %x\n",*cptr);

	return 0;
}
