#include <stdio.h>

static int sgvar = 100;
int gvar = 200;

void display(void);
void fun(void);

int main()
{
	fun();
	sgvar++;
	gvar++;
	display();
	return 0;
}
void display(void)
{
	printf("sgvar = %d gvar = %d\n",sgvar,gvar);

	return ;
}
