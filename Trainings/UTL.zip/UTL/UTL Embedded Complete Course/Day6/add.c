#include <stdio.h>

void add();
//void add(int a,int b);

int main()
{
	int var1 = 10, var2 = 20;

	add(var1,var2);	// var1 var2 are actual parameters
	add(var1+ 10,var2);	// var1 var2 are actual parameters
	add(100,200);	// var1 var2 are actual parameters

	return 0;
}

void add(int num1, int num2 )//num1 num2 are formal parameters
{
	printf("%d + %d = %d\n",num1,num2,num1 + num2);

	return ;
}

