#include <stdio.h>

extern int gvar;
//extern int sgvar;
void fun(void)
{
	gvar++;
//	sgvar++;
	printf("In fun file 2 gvar = %d\n",gvar);
//	printf("In fun file 2 sgvar = %d\n",sgvar);
	
}
