#include <stdio.h>
register int var;
int main()
{
	auto int counter;
	{
		register int counter;
		counter = 10;
		printf("counter = %d\n",counter);
	}
	//int* ptr = &counter;
	//printf("enter a value \n");
	//scanf("%d",&counter);

	counter = 20;
	printf("counter = %d\n",counter);

	return 0;
}
