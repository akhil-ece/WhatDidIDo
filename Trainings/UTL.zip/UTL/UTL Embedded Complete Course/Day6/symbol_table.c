#include <stdio.h>

int u_gvar;
int i_gvar = 100;

static int u_sgvar;
static int i_sgvar = 200;

int main()
{
	int lvar = 10;
	static int svar = 300;;;;;;;;;;;;

	printf("main = %p\n",main);
	printf("&u_gvar = %p\n",&u_gvar);
	printf("&i_gvar = %p\n",&i_gvar);
	printf("&u_sgvar = %p\n",&u_sgvar);
	printf("&i_sgvar = %p\n",&i_sgvar);
	printf("&svar = %p\n",&svar);
	return 0;
}
