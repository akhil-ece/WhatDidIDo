#include <stdio.h>
//int gvar; // global scope

void fun(void);
void display(void);
extern int gvar ; // only declaration
int main()
{
	//int gvar = 10; //block scope
	fun();
	printf("gvar in main = %d\n",gvar);
	printf("gvar in main after call= %d\n",gvar);
	return 0;
}
int gvar;
void fun(void)
{
	gvar = 100;
	printf("Inside fun gvar++ =  %d\n",gvar++);
	display();
	return;
}
void display(void)
{
	printf("gvar = %d\n",gvar);
	return ;
}





