#include <stdio.h>

int main()
{
	int arr[] = {1,2,3,4,5};

	printf("arr = %p\n",arr);	//addr of 1
	printf("&arr = %p\n",&arr);

	printf("arr + 1 = %p\n",arr + 1);//addr of 2
	printf("&arr + 1 = %p\n",&arr+ 1);//addr of 2
	return 0;
}
