#include <stdio.h>
//auto int gvar;
int main()
{
		int var = 100;
	{
		auto int var; 
		printf("var = %d\n",var);
		var = 200;
	}
		printf("var = %d\n",var);

	return 0;
}
