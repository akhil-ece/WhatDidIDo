#include <stdio.h>

int sum(void(*ptr)(void));
void display(void);

int main()
{
	int res = 0;
	res = sum(display);
	printf("Inside main res = %d\n",res);
	return 0;
}

int sum(void (*ptr)(void))
{
	ptr();
	return 10 + 20;
}
void display(void)
{
	printf("Inside display\n");
	return;
}
