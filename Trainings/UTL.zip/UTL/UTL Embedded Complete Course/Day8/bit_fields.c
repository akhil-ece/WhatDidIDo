#include <stdio.h>
#pragma pack(1)
int main()
{
	struct cal
	{
		int date:5;
		unsigned int month:4;
		int year;
	};

	struct cal day;

	day.date = 31;

	printf("&day.date = %p\n",&day.date);

	printf("sizeof(struct cal) =%ld\n",sizeof(struct cal))	;

	return 0;
}
