#include <stdio.h>

#pragma pack(6)

int main()
{
	struct test
	{
		int var;
		char ch;
		int a;
	};//__attribute__((__packed__));

	struct temp
	{
		int var;
		char ch;
		int a;
	};

	printf("sizeof(struct test) = %ld\n",sizeof(struct test));
	printf("sizeof(struct temp) = %ld\n",sizeof(struct temp));
/*
	if(t1.var == t2.var)
		printf("Equal\n");
	else
		printf("Not Equal\n");
*/
	return 0;
}
