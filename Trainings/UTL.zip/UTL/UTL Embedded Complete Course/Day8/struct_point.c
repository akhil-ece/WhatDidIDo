#include <stdio.h>
#include <stdlib.h>
struct student
{
	int roll_no;
	char name;
}s1;

int main()
{

	struct student* ptr = (struct student*)malloc(sizeof(struct student));
	//struct student* ptr = &s1;

	ptr -> roll_no = 100;
	ptr -> name = 'a';
	
	printf("%d %c\n",s1.roll_no,s1.name);
	
	printf("ptr -> roll_no = %d\n",ptr->roll_no);
	printf("ptr -> name = %d\n",ptr->name);
	//printf("sizerof(ptr) = %ld\n",sizeof(ptr));
	return 0;
}
