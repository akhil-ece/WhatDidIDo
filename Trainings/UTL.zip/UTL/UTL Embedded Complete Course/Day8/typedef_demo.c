#include <stdio.h>

int main()
{
	typedef static int s_int; 	
	typedef register int r_int; 	
	typedef unsigned long int UL_64t;

	UL_64t var1,var2;

	printf("%ld %ld\n",sizeof(var1),sizeof(var2));
	return 0;
}
