#include <stdio.h>

int main()
{
	typedef enum Week_Day{M ,T = -1,W = 3, T,F,S,S}today;

	 today day1,day2;
	enum Week_Day day;
	//Tue = 5;

	day = Wed ;
	
	printf("day = %d\n",day);

	printf("sizeof(enum Week_Day) = %ld\n",sizeof(enum Week_Day));

	return 0;
}
