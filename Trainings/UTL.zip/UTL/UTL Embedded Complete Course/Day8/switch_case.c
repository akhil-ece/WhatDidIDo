#include <stdio.h>

int main()
{
	enum {BLUE,GREEN,RED,YELLOW,ORANGE}colors;// UNAMED ENUMERATOR

	colors = 1;	
	switch(BLUE)
	{
		case 0: printf("BLUE\n");
			break;
		case GREEN: printf("GREEN\n");
			break;
		default: printf("Default\n");
	
	}
	return 0;
}
