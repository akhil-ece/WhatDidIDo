#include <stdio.h>
#include <string.h>
struct student
{
	int roll_no;
	char name[20];
};

int main()
{
	struct student s1;// = {.name = "Sam"};

	//strcpy(s1.name,"Some Name");
	s1.roll_no = 100;
	printf("Enter the name\n");
	scanf("%s",s1.name);
	//s1.name = "Sam";

	printf("%d %s\n",s1.roll_no,s1.name);

	return 0;
}
