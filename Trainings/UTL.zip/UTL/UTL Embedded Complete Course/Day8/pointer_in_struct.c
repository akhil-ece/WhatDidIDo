#include <stdio.h>

struct student
{
	int roll_no;
	char* name;	
};

int main()
{
	struct student s1;// = {101,"Ram"};

	s1.roll_no = 200;
	s1.name = "RAM";

	printf("roll no = %d\n",s1.roll_no);
	printf("name = %s\n",s1.name);
	return 0;
}
