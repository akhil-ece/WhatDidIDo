#include <stdio.h>

int sum(int,int);
int (*ptr)(int,int);// function pointer declaration
int main()
{
	int a = 10,b = 20,c = 0;
	ptr = sum;//pointer initiaization
	//c = ptr(a,b);//c = sum(a,b)
	c  = (*ptr)(a,b);
	printf("c = %d\n",c);
	printf("sizeof(ptr) = %ld\n",sizeof(ptr));	
	return 0;
}

int sum(int var1,int var2)
{
	return var1 + var2;
}
