#include <stdio.h>

struct student
{
	int roll_no;
	char name;
};

int main()
{
	struct student s[2] = {{100,'a'},{101,'b'}};
	struct student* ptr = s;
		
	ptr++;

	printf("%d %c\n",ptr->roll_no,ptr->name);

	//printf("(*(s+1)).roll_no = %d\n",(*(s+1)).roll_no);

	return 0;
}
