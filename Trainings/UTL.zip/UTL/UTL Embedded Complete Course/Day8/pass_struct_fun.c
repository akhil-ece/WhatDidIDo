#include <stdio.h>
#include <string.h>
struct student
{
	int roll_no;
	char name[10];
	float marks;
};

void display(struct student*);

int main()
{
	struct student s1 = {101,"RAM",70.23};
	
	display(&s1);
	printf("Name:%s\nRoll No:%d\nMarks:%f\n",s1.name,s1.roll_no,s1.marks);	

	return 0;
}
void display(struct student* s)
{
	s->roll_no = 200;
	strcpy(s->name,"ROY");
	s->marks = 85;

	printf("Name:%s\nRoll No:%d\nMarks:%f\n",s->name,s->roll_no,s->marks);	

	return;
}
