#include <stdio.h>

struct student
{
	int roll_no;//  = 100;
	char name;// = 'a';
}s2 = {200,'a'};

int main()
{
	
	int roll_no = 1001;
	char name = 's';
	struct student s1;//  = {.name = 'c'};
	//s1.roll_no = 300;
	//s1.name = 'b';
	printf("Enter a int and char\n");
	scanf("%d %c",&s1.roll_no,&s1.name);

	printf("s1.roll_no = %d\n",s1.roll_no);
	printf("s1.name = %c\n",s1.name);
	return 0;
}
