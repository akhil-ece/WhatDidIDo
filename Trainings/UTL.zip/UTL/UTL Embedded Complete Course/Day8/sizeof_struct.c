#include <stdio.h>

struct student
{
	double var;
	short int roll_no;
	char name;
	int a;
}s1;

int main()
{
	printf("sizeof(s1) = %ld\n",sizeof(s1));

	return 0;
}
