#include <stdio.h>

int main()
{
	int var = 0xABCDEF55;
	int* iptr = &var;
	char* cptr = &var;
	//printf("*iptr = %X\n",*iptr);
	//printf("*cptr = %X\n",*cptr);

	if(*cptr == 0x55)
		printf("Little Endian\n");
	else
		printf("Big endian\n");
	return 0;
}
