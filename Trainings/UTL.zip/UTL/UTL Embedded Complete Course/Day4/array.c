// Documentation

#include <stdio.h>

int main()
{
	int array[] = {10,20,30,40,50};

	int a[5];// = array;

//	a = array;

	a[0] = array[0];

	printf("array = %p\n",array);	
	printf("&array[0] = %p\n",&array[0]);	
//	array++;

	array[0]++;

	printf("array[0] = %d\n",array[0]);

	return 0;
}
