#include <stdio.h>

int main()
{
	int arr[] = {10,20,30,40};

	int* ptr = &arr[0];
	//int* ptr1 = &arr[3];

	//ptr + ptr1;
	
	printf("*ptr = %d\n",*ptr);//10	
	printf("ptr = %p\n",ptr);
		
	ptr++;
	--ptr;
	//ptr = ptr + 4;

	//ptr = ptr - 2;

	printf("*ptr = %d\n",*ptr);//30	
	printf("ptr = %p\n",ptr);
	return 0;
}
