#include <stdio.h>

int main()
{
	int arr[2][2], i = 0, j = 0;

	printf("Enter the array  elements\n");

	for(i = 0; i < 2 ;i++)
	{
		for(j = 0; j < 2 ;j++)
			scanf("%d",&arr[i][j]);
	}
	printf("The array elements are\n");
	for(i = 0; i < 2 ;i++)
	{
		for(j = 0; j < 2 ;j++)
			printf("arr[%d][%d] = %d\n",i,j,arr[i][j]);
	}
	

	return 0;
}
