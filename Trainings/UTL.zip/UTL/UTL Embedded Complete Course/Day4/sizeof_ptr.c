#include <stdio.h>

int main()
{
	int* iptr;
	char* cptr;
	float* fptr;
	double* dptr;

	printf("sizeof(iptr) = %ld\n",sizeof(iptr));
	printf("sizeof(cptr) = %ld\n",sizeof(cptr));
	printf("sizeof(fptr) = %ld\n",sizeof(fptr));
	printf("sizeof(dptr) = %ld\n",sizeof(dptr));

	printf("sizeof(*iptr) = %ld\n",sizeof(*iptr));
	printf("sizeof(*cptr) = %ld\n",sizeof(*cptr));
	printf("sizeof(*fptr) = %ld\n",sizeof(*fptr));
	printf("sizeof(*dptr) = %ld\n",sizeof(*dptr));

	return 0;
}
