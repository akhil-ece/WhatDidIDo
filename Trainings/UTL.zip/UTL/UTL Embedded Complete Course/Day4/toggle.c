#include <stdio.h>

int main()
{
	char str[15], i = 0;

	printf("Enter a string\n");
	//scanf("%s",str);
	gets(str);

	printf("Before toggling string is %s\n",str);
	// TODO

	//for(i = 0;i < sizeof(str) ;i++)
	for(i = 0;str[i] != '\0' ;i++)
	{
		if(str[i] >= 'A' && str[i] <= 'Z')
			str[i] = str[i] + ('a' - 'A');
		else if(str[i] >= 'a' && str[i] <= 'z')
			str[i] = str[i] - ('a' - 'A');
			
		
	}

	printf("After toggling string is %s\n",str);

	return 0;
}
