#include <stdio.h>

int main()
{
	int var = 100;
	int* ptr = &var;
	int** dptr = &var;

	printf("sizeof(dptr) = %ld\n",sizeof(dptr));

	printf("dptr = %p\n",dptr);;// Address of ptr
	printf("*dptr = %p\n",*dptr);//Addr of var
	printf("**dptr = %d\n",**dptr);
	return 0;
}
