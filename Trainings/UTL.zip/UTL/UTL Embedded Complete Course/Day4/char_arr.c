#include <stdio.h>

int main()
{
	char str1[] = "Hello";
	char str2[] = "Hello";

	if(str1[0]== str2[0])
		printf("Equal\n");
	else
		printf("Not Equal\n");

/*	char carr[3] = {'E','C','E'};
	char str[] = "ECE\0 VRSCE";

	printf("sizeof(carr) = %ld\n",sizeof(carr));
	printf("sizeof(str) = %ld\n",sizeof(str));
	
	printf("carr[1] =  %c\n",carr[1]);
	printf("str[1] = %c\n",str[1]);
	
	printf("str = %s\n",str);
	printf("carr = %s\n",carr);

	printf("%s\n",&str[1])	;	*/
	return 0;
}
