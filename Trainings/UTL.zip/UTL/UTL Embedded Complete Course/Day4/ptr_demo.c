#include <stdio.h>

int main()
{
	const int var = 100;
	int* ptr = &var;
	
	//var = 200;
	*ptr = 200;

	printf("var = %d\n",var);

	return 0;
}
