#include <stdio.h>

int main()
{
	char string[3][10] ;//= {"Fruits","Flowers","Mobiles"};
/*
	string[0] = "Fruits";
	string[1] = "Flowers";
	string[2] = "Mobiles";
*/
	string[0][0] = 'f';
	printf("sizeof(string) = %ld\n",sizeof(string));
	printf("sizeof(string[2]) = %ld\n",sizeof(string[2]));
	printf("sizeof(string[2][1]) = %ld\n",sizeof(string[2][1]));

	printf("%s\n",string[0]);
	printf("%p\n",string);

	printf("%s\n",&string[1][4]);
	
	printf("string[1][2] = %c\n",string[1][2]);

	return 0;
}
