#include <stdio.h>

int main()
{
	char string[3][10], i = 0;

	printf("Enter three strings\n");

	for(i = 0 ;i < 3 ;i++)
		scanf("%s",string[i]);

	printf("The enetred strings are\n");
	for(i = 0 ;i < 3 ;i++)
		printf("%s\n",string[i]);

	return 0;
}
