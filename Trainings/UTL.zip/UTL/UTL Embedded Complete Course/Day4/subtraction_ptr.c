#include <stdio.h>

int main()
{
	int arr[] = {10,20,30,40,50,60,70,80,90,100};
	char* ptr1;
	int*  ptr2;

	ptr1 = &arr[1] ;
	ptr2 = &arr[2] ;

	printf("ptr1 = %p ptr2 = %p\n",ptr1,ptr2);
	printf("ptr2 - ptr1 = %ld\n",ptr2 - ptr1);

	return 0;
}
