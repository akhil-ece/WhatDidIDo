//Documentation

#include <stdio.h>

int main()
{
	int size = 0, i = 0;
	int arr[size];
	printf("Enter the size of array\n");
	scanf("%d",&size);

	//int arr[size];// = {10,20,30,40};this initialization is not allowed
/*
	arr[0] = 10;
	arr[1] = 20;
	arr[2] = 30;
	arr[3] = 40;
*/
	printf("Enter %d array elements\n",size);

	for(i = 0; i < size ;i++)
		scanf("%d",&arr[i]);

	printf("The entered array is\n");
	for(i = 0; i < size ;i++)
		printf("%d\n",arr[i]);
	return 0;
}
