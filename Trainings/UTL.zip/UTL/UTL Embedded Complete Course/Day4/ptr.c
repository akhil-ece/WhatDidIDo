#include <stdio.h>

int main()
{
	int a = 10, b;
	int* ptr = &a;

	printf("&*ptr = %p\n",&*ptr);

//	b = &a;

	printf("&a = %p\n",&a);
	printf("ptr = %p\n",ptr);
	printf("*ptr = %d\n",*ptr);
/*
	*ptr = 100;
	printf("*ptr = %d\n",*ptr);//100
	printf("a = %d\n",a);//100
	//printf("b = %p\n",b);
*/
	//printf("*b= %d\n",*b);
	return 0;
}
