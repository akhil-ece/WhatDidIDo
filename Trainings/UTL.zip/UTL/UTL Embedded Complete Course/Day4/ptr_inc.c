#include <stdio.h>

int main()
{
	char ch[] = "Welcome";
	char* cptr = &ch[0];

	cptr++;


	printf("%c\n",*cptr++);

	printf("%s\n",cptr);
	printf("%s\n",cptr+ 2);
	return 0;
}
