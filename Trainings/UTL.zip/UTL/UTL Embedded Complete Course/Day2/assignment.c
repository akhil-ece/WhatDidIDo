// Documentation

#include <stdio.h>

int main()
{
	int var1 = 10,var2 = 20;

	var1 + var2 = 30;

	return 0;
}
