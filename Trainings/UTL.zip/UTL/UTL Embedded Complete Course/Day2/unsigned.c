// Documentation

#include <stdio.h>

int main()
{
	unsigned int ch = -2;
	//unsigned char ch = -2;

	printf("ch = %u\n",ch);	

	return 0;
}
