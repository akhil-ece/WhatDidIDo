//Documentation

#include <stdio.h>

int main()
{
	int const  var = 100;
	//var = 200;

	printf("var = %d\n",var);

	return 0;
}
