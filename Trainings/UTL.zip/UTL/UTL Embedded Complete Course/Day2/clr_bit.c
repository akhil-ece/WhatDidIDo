//Documentation

#include <stdio.h>

int main()
{
	int num = 0,pos = 0;

	printf("Enter the number and the position\n");
	scanf("%d %d",&num,&pos);

	num &= ~(1 << pos);//num = num | (1<<pos);

	printf("num = %d\n",num);

	return 0;
}
