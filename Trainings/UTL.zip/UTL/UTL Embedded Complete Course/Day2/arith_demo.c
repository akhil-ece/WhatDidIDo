//Documentation

int main()
{
	float f = 5.313 % 2;

	return 0;
}
