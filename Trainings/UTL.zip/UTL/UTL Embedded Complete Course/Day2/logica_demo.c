//Documentation

#include <stdio.h>

int main()
{
	printf("-10 && 20 = %d\n",-10 && 20);
	printf("-10 || 0 = %d\n",-10 || 0);
	
	printf("!(-100) = %d\n",!(-100));
	printf("!!(-100) = %d\n",!!(-100));
	

	return 0;
}
