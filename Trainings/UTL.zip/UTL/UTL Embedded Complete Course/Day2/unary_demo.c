// Documentation

#include <stdio.h>

int main()
{
	int a = 5,b = 0;

	printf("%d %d %d %d\n",++a,a++,++a,a++);

	//b = ++a;

	//printf("a = %d b = %d\n",a,b);

	return 0;
}
