//Documentation

#include<stdio.h>

int main()
{
	int ret;
	int var1 = 100,var2 = 1000;

	ret = printf("var1= %d var2 = %d\n",var1,var2);


//	ret = printf("Welcome\n");

	printf("ret = %d\n",ret);

	return 0;
}
