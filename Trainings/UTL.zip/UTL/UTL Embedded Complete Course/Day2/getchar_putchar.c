// Documentation

#include <stdio.h>

int main()
{
	int ch = 0;
	int ret = 0;
	ch = getchar();

	putchar(ch);

	putchar('\n');

	ret = putchar(97);
	
	putchar('\n');

	putchar(ret);
	
	putchar('\n');

	
	return 0;
}
