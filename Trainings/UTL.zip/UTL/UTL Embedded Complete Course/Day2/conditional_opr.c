// Documentation

#include <stdio.h>

int main()
{
	int var1 = 10,var2 = 20,ret = 0;

	ret = (var1 > var2)? printf("var1 is greater\n"):printf("var2 is greater\n");
	
	printf("ret = %d\n",ret);

	return 0;
}
