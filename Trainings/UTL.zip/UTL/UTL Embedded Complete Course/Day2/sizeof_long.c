// Documentation

#include <stdio.h>

int main()
{
	printf("sizeof(long long long int) = %ld\n",sizeof(long long long int));

//	printf("sizeof(long int) = %ld\nsizeof(short int) = %ld\n",sizeof(long int ),sizeof(short int));

	return 0;
}
