// Documentation

#include <stdio.h>

int main()
{
	int ret = 0,var1 = 0,var2 = 0;

	printf("Enter 2 values\n");

	ret = scanf("%d %d",&var1,&var2);

	printf("ret = %d\n",ret);

	return 0;
}
