#include <stdio.h>

int main()
{
	int a = 0,b = 1,c = 2, m = 0;

	m = a++ && ++b || ++c;

	printf("a = %d b = %d c = %d m = %d\n",a,b,c,m);

	return 0;
}
