// Documentation

#include <stdio.h>

int main()
{
	//void var;

	printf("sizeof(void) = %ld\n",sizeof(void));

	return 0;
}
