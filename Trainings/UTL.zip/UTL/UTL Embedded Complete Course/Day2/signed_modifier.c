//To demonstrate signed modifier

#include <stdio.h>

int main()
{
	char ch = -1;

	printf("ch = %d\n",ch);

	return 0;
}
