// Documentation

#include <stdbool.h>
int main()
{
	bool bvar;
	
	bvar = -10;

	printf("bvar = %d\n",bvar);
	printf("sizeof(bvar) = %ld\n",sizeof(bvar));

	return 0;
}
