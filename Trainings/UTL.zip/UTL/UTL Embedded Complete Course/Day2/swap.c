// Documentation

#include <stdio.h>

int main()
{
	int var1 = 10,var2 =20;
	printf("before swap logic\n");
	printf("var1 = %d var2 = %d\n",var1,var2);

	//Logic 1
	var1 = var1 + var2;
	var2 = var1 - var2;
	var1 = var1 - var2;
	// Logic 2
	var1 = var1 * var2;
	var2 = var1 / var2;
	var1 = var1 / var2;

	printf("After swap logic\n");
	printf("var1 = %d var2 = %d\n",var1,var2);


	return 0;
}
