// Documentation

#include <stdio.h>

int main()
{
	unsigned char ch = 0x80;

	ch >>= 2;//ch = ch >> 2;

	printf("ch = %x\n",ch);
	printf("ch = %d\n",ch);

	return 0;
}
