// To check whether default is signed or unsigned

#include <stdio.h>

int main()
{
	int var = -10;

	printf("var=  %d\n",var);

	return 0;
}
