//Documentation

#include <stdio.h>

int main()
{
	int var = 10;
	printf("address of var = %p\n",&var);

	return 0;
}
