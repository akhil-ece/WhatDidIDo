// Documentation

#include <stdio.h>

int main()
{
	int num = 0, sum = 0;

	printf("Enter a number\n");
	scanf("%d",&num);

	while(num)
	{
		sum += num % 10 ;
		num /= 10;
	}
	printf("sum = %d\n",sum );
	return 0;
}
