//Documentation

#include <stdio.h>

int main()
{
	int i = 0;

	if( i > 5,0,printf("VRSCE\n"),i++)
	{
		printf("inside if i = %d\n",i);
	}
	printf("outside if i = %d\n",i);

	return 0;
}
