#include <stdio.h>

int main()
{
	int i = 0, j = 0;

	for(; ; );
	{
		printf("Vijayawada\n");
	}
	printf("i = %d j = %d\n",i,j);
	
	return 0;
}
