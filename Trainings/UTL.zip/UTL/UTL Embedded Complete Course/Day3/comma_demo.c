// Documentation

#include <stdio.h>

int main()
{
	int i = (10,20,30);

	printf("i = %d\n",i);

	return 0;
}
