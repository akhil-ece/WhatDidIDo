#include <stdio.h>

int main()
{
	int arr[10] = {10,20,30,[5] = 50,40}, i = 0 ;

	for(; i < 10 ;i++)
		printf("<%p> arr[%d] = %d\n",&arr[i],i,arr[i]);

	printf("sizeof(arr) = %ld\n",sizeof(arr));	
	printf("sizeof(arr[1]) = %ld\n",sizeof(arr[1]));	
//arr[5] = {10,20,30,40,50}; not valid
/*
	arr[0] = 10;
	arr[1] = 20;
	arr[2] = 30;
	arr[3] = 40;
	arr[4] = 50;*/

//	 arr + 2;
//	arr++;


	return 0;
}
