#include <stdio.h>

int main()
{
	int num = 0, rev = 0;

	printf("Enter a number\n");
	scanf("%d",&num);

	while((num % 10) == 0)
	{
		printf("%d",0);
		num /= 10;
	}
	
	do
	{
		rev = rev * 10 + num % 10;	
		num /= 10;

	}while(num);
	printf("%d\n",rev);
}
