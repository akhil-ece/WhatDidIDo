// Documentation

#include <stdio.h>

int main()
{
	 int ch = 65;
	const int cvar = 65;

	switch(ch )
	{
		default:
			printf("Default\n");
			break;
		case 1:
			printf("case 1\n");
			break;
		case cvar:
			printf("case 65\n");
			break;

	}

	return 0;
}
