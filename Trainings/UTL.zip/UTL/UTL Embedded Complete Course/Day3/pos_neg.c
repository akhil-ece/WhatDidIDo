#include <stdio.h>

int main()
{
	int num = 0;

	printf("Enter a number\n");
	scanf("%d",&num);

	if(num & (1 << sizeof(num)* 8 -1))
		printf("%d is -ve\n",num);
	else
		printf("%d is +ve\n",num);
		

	return 0;
}
