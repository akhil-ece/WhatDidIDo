#include <stdio.h>

int main()
{
	int arr[]= {}, i = 0;

	printf("sizeof(arr) = %ld\n",sizeof(arr));	
/*	for(i = 0; i < 5; i++)
		printf("%d\n",arr[i]);
	printf("Enter 5 array elements\n");
	for(i = 0; i < 5; i++)
		scanf("%d",&arr[i]);

	printf("The elements of the array are \n");
	for(i = 0; i < 5; i++)
		printf("%d\n",arr[i]);
*/	

	return 0;
}
