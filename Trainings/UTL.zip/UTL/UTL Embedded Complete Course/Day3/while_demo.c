// Documentation

#include <stdio.h>

int main()
{
	int i = 0, j = 0;

	while(printf("Hello "),i < 5)
	{
		printf("ECE\n");
		i++;
	}
	printf("i = %d j = %d\n",i,j);
	
	return 0;
}
