//Documentation

#include <stdio.h>

int main()
{

	printf("sizeof('A') = %ld\n",sizeof('A'));
	printf("sizeof(3.14f) = %ld\n",sizeof(3.14f));

/*	int a = 10,b = 20;
	char  c = 0;

	printf("%ld\n",sizeof(c + a + b));
	
	printf("c = %d\n",c);	
*/
	return 0;
}
