#include <stdio.h>

int main()
{
	int marks = 0;

	printf("Enter the marks(0-100)\n");
	scanf("%d",&marks);

	if(marks <= 100 && marks >= 90)
		printf("10 points\n");	
	else if(marks <= 89 && marks >= 80)
		printf("10 points\n");	
	else
		printf("Last option\n");

	return 0;
}
