#include <stdio.h>

int main()
{
	int num = 0,one = 0, zero = 0, i =0;

	printf("Enter a number\n");
	scanf("%d",&num);

	for(;i < sizeof(num) * 8;i++)
	{
		if(num & 1)
			one++;
		else
			zero++;

		num >>= 1;
	}
	
	printf("ones = %d zeros = %d\n",one,zero);

	return 0;
}
