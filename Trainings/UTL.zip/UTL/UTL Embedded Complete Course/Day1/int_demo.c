// To demonstrate integer data type

#include <stdio.h>

int main()
{
	int var = 0101;
	//int var = 0x41;
	//int var = 65;

	printf("var in decimal = %d\n",var);
	printf("var in hexa decimal = %x\n",var);
	printf("var in octal = %o\n",var);

	return 0;
}
