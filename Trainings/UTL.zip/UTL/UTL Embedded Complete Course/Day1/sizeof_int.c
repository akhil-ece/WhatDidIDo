// To find size of int data type
#include <stdio.h>

int main()
{
	printf("sizeof int = %ld\n",sizeof(int));

	return 0;
}
