// To demonstrate char data type

#include <stdio.h>

int main()
{
	char ch = 97;

	printf("ch = %c\n",ch);
	printf("ch = %d\n",ch);
	printf("ch = %x\n",ch);
	printf("ch = %o\n",ch);

	return 0;
}
