/* Author: Abhilash
 * Date : 29-01-2019
 * Purpose: First C Program
*/
#include"stdio.h"	// Include stdio.h content

int main() // Main is the entry point function for application program
{			//Start ofa block of code	


	printf("Hello World\n");// Standard library function
	return 0;	//return the status of main
}	// End of the block
