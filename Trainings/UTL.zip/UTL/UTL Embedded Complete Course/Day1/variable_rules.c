// To demosntrate rules of variables

int main()
{
	//int 2var;variable name should not start with digit

	int case;

	int 	my,var;
	int var_2;
	int var2;
	int _2var;
	int printf;
	int main;
	return 0;
}
