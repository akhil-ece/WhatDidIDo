// To find size of char data type
#include <stdio.h>

int main()
{
	printf("sizeof char = %ld\n",sizeof(char));

	return 0;
}
