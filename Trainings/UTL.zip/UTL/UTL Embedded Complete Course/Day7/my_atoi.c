#include <stdio.h>

int my_atoi(const char*);

int main()
{
	char str[] = "456";
	printf("%s %d\n",str,my_atoi(str));
	
	printf("atoi(\"1234\") = %d\n",my_atoi("1234"));

	return 0;
}
int my_atoi(const char* ptr)
{
	int num = 0;

	while(*ptr)
	{
		num = num * 10 + (*ptr - '0');
		ptr++;

	}
	return num;
}
