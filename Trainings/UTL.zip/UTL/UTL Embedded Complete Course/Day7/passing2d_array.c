#include <stdio.h>

void display(int,int,int(*)[]);

int main()
{
	int matrix[][4] ={10,20,30,40,50,60,70},row = 0,col = 0;;

	col = sizeof(matrix[0])/sizeof(matrix[0][0]);
	row = sizeof(matrix)/sizeof(matrix[0]);
	display(row,col,matrix);
	return 0;
}

void display(int row,int col,int (*p)[col])
{
	int i = 0, j = 0;

	for(i = 0; i < row ; i++)
	{
		for(j = 0; j < col ;j++)
			printf("%d\n",p[i][j]);

	}
}
