#include <stdio.h>

int* add(int ,int);

int main()
{
	int a = 20,b = 30;
	int* ptr = 0;

	ptr = add(a,b);// ptr = &sum

	printf("*ptr = %d\n",*ptr);
	return 0;
}
int* add(int var1,int var2)
{
	static int sum = 0;
	sum = var1 + var2;

	return &sum;
	
}
