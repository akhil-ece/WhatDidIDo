#include <stdio.h>
//#include <string.h>
char* my_strcpy(char*,const char*);
int main()
{
	char dest[3] = {0},src[] = "Welcome";

	printf("Before copy dest = %s src = %s\n",dest,src);
	my_strcpy(dest,src);
	printf("After copy dest = %s src = %s\n",dest,src);

	return 0;
}
char* my_strcpy(char* dest,const char* src)
{
	int i = 0;
	for(i = 0; src[i] != '\0';i++)
		dest[i] = src[i];
	dest[i] = src[i];
	return dest;
}
