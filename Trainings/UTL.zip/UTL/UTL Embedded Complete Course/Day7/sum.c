#include <stdio.h>

int add(int);

int main()
{
	int num = 5,sum = 0;

	if(num < 0)
	{
		printf("-ve number not allowed\n");
	}
	else
	{
		sum = add(num);

		printf("sum of %d numbers  = %d\n",num,sum);
	}
	return 0;
}

int add(int n)
{
	if(n == 1 )
		return 1;
	else
		return n + add(n-1);

}
