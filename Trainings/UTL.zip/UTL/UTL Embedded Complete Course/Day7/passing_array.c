#include <stdio.h>

void inc(int []);
//void inc(int [],int);

int main()
{

	int arr[] = {10,20,30,40,50,60,70,80,90,100},size = 0,i = 0;

	size = sizeof(arr)/sizeof(arr[3]);

	inc(arr);

	for(i = 0 ; i < size ;i++)
		printf("%d\n",arr[i]);

	return 0;
}

void inc(int arr[])
{
	int i = 0,size = 0;

	size = sizeof(arr)/sizeof(arr[3]);
	
	//arr++;
	for(i = 0; i < size ; i++)
		arr[i]++;
}
