#include <stdio.h>

int fact(int);

int main()
{
	int num = -5,factorial = 0;

	if(num < 0)
	{
		printf("Factorial of -ve number does not exist\n");
	}
	else
	{
		factorial = fact(num);

		printf("%d! = %d\n",num,factorial);
	}
	return 0;
}

int fact(int n)
{
	if(n == 1 || n == 0)
		return 1;
	else
		return n * fact(n-1);

}
