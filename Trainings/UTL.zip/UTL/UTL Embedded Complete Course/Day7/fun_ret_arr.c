#include <stdio.h>

int* fun(void);

int main()
{
	int* ptr = NULL,i = 0;

	ptr = fun();

	for(i = 0; i < 5 ;i++)
		printf("ptr[%d] = %d\n",i,ptr[i]);

	return 0;
}

int* fun(void)
{
	static int arr[] = {10,20,30,40,50};

	return arr;

}
