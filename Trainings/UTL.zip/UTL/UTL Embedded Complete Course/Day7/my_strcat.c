#include <stdio.h>

char* my_strcat(char*,const char*);

int main()
{
	char dest[10] = "Hi " ,src[] = "Hello";

	printf("Before concat dest = %s src = %s\n",dest ,src);	
	printf("%s\n",my_strcat(dest,src));

	printf("After concat dest = %s src = %s\n",dest ,src);	
	return 0;
}
char* my_strcat(char* d,const char* s)
{
	int i =0 ,j = 0;

	for(i = 0; d[i] != '\0';i++);

	for(j = 0; s[j] != '\0';j++,i++)
		d[i] = s[j];

	d[i] = s[j];

	return d;
}
