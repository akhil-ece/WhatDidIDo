#include <stdio.h>

int main()
{
	auto int i = 0;

	if(i < 5)
	{
		i++;
		printf("i = %d\n",i);
		main();

	}
	printf("i = %d\n",i);

	return 0;
}
