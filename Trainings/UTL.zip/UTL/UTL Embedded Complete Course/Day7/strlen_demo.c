#include <stdio.h>
//#include <string.h>

int my_strlen(const char*);
int main()
{
	char str[] = "Welcome";
	
	int len = 0;

	len = my_strlen(str);

	printf("len = %d\n",len);

	return 0;
}
int my_strlen(const char* s)
{
	int count = 0;

	while(*s++ && ++count);
/*	while(*s)
	{
		count++;
		s++;
	}*/
	return count;
	//TODO

}
