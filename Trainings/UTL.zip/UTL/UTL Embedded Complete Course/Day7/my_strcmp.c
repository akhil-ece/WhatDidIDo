#include <stdio.h>
int my_strcmp(const char*,const char*);
int main()
{
	char s1[] = "Asdf",s2[] = "Hello";

	printf("strcmp(s1,s2) = %d\n",my_strcmp(s1,s2));

	return 0;
}
int my_strcmp(const char* s1,const char* s2)
{
	while(*s1 != '\0' && *s2 != '\0')
	{
		if(*s1 == *s2)
		{
			s1++;
			s2++;
		}
		else
			return *s1 - *s2;
	}
	return 0;

}
