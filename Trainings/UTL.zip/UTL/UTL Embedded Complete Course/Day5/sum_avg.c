#include <stdio.h>

int main()
{
	int arr[] = {10,20,30,40},sum = 0, i = 0;
	float avg = 0;
	int* ptr = arr;
	
	for(i = 0; i < 4 ; i++)
		sum = sum + (*ptr++);

	avg = sum / 4;

	printf("sum = %d avg = %f\n",sum,avg);

	return 0;
}
