#include <stdio.h>

int main()
{
	int arr[] = {10,20,30,40,50}, i = 0;
	
	int* ptr = arr;

	for(i = 0; i < 5 ;i++)
		printf(" %d %d \n",ptr[i],*(ptr + i));
	
	for(i = 0; i < 5 ;i++)
		printf("%d\n",*ptr++);

	/*ptr = ptr + 4;
	
	printf("*ptr = %d\n",*ptr);
	printf("ptr[-3] = %d\n",ptr[-3]);
	printf("*ptr = %d\n",*ptr);
*/


//printf("%d %d %d %d\n",arr[i],*(arr + i),i[arr],*(i + arr));

	printf("%d\n",arr[i - 2]);
	return 0;
}
