#include <stdio.h>

int main()
{
	if(sizeof(int) < -3.16f)
		printf("True\n");
	else
		printf("False\n");

//	int a = 3.99;

//	printf("a = %d\n",a);

	return 0;
}
