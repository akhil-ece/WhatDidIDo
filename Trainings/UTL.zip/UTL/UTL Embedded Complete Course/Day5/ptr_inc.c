#include <stdio.h>

int main()
{
	char ch[] = "Hello";

	char* cptr = ch;

	cptr = cptr / 2;

	printf("<%p>%s\n",cptr,cptr);
	//printf("++*cptr = %c\n",++*cptr);//I
	//printf("*cptr++ = %c\n",*cptr++);//H
	//printf("++*cptr++ = %c\n",++*cptr++);
	printf("*++cptr = %c\n",*++cptr);//e
	printf("%s\n",ch);
	printf("<%p>%s\n",cptr,cptr);

	return 0;
}
