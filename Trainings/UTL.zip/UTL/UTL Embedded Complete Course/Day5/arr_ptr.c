#include <stdio.h>

int main()
{
	int arr[] = {10,20,30,40,50};
	int* ptr[] = {arr,arr+1,arr+2,arr+3,arr+4};

	printf("ptr[1][1] = %d\n",ptr[1][1]);
	printf("ptr[1][2] = %d\n",ptr[1][2]);

	printf("ptr = %p\n",ptr);
	printf("arr = %p\n",arr);
	printf("*ptr = %p\n",*ptr);
		

/*
	printf("ptr[1] = %p\n",ptr[1]);//addr of 20
	printf("*ptr[1] = %d\n",*ptr[1]);
	printf("ptr[1][0] = %d\n",ptr[1][0]);//20

	printf("sizeof(ptr) = %ld\n",sizeof(ptr));
	printf("sizeof(ptr[1]) = %ld\n",sizeof(ptr[1]));
*/

	return 0;
}
