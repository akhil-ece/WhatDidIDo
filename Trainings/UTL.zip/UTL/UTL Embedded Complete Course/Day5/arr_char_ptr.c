#include <stdio.h>

int main()
{
	char* cptr[] = {"Hi", "Hello","Welcome","ECE VRSCE VIJAYAWADA"};

	printf("sizeof(cptr) = %ld\n",sizeof(cptr));

	printf("%s\n",cptr[3] + 4);
	cptr[2] = "INDIA";
	
	//cptr[2][0] = 'w';

	printf("%c\n",*(cptr[3]+1));//cptr[3][1]
	printf("%s\n",cptr[2]);// *(cptr + 2)
	return 0;
}
