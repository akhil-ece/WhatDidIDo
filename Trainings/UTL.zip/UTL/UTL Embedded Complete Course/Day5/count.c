#include <stdio.h>

int main()
{
	//char str[20];
	char* cptr = "ABCD123qwert@#!$";

	//char* cptr = str;
	int alpha = 0, digit = 0, sc = 0;

	while(*cptr !='\0')
	{
		if((*cptr >= 'A' && *cptr <= 'Z') ||
		    *cptr >= 'a' && *cptr <= 'z')
			alpha++;
		else if(*cptr >= '0' && *cptr <= '9') 
			digit++;
		else
			sc++;
		cptr++;
	}

	printf("Alphabets = %d Digits = %d Special Characters = %d\n",alpha,digit,sc);

	
	
	return 0;
}
