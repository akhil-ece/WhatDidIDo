#include <stdio.h>

int main()
{
	void* vptr;

	int var = 65;
	char ch = 'a';
	vptr = &var;
	printf("*vptr = %d\n",*(int*)vptr);
	vptr = &ch;
	printf("*vptr = %c\n",*(char*)vptr);

	printf("sizeof(vptr) = %ld\n",sizeof(vptr));

	return 0;
}
