#include <stdio.h>

int main()
{
	int arr[2][2] = {10,20,30,40};

	printf("*(*(arr + 1) + 1) = %d\n",*(*(arr+1)+1));

	printf("&arr[0][0] = %p\n",&arr[0][0]);
	printf("*arr = %p\n",*arr);//addr of 10
	
	printf("**arr = %d\n",**arr);//10

	printf("*arr[1] = %d\n",*arr[1]);//30
	printf("*(arr[1] + 1) = %d\n",*(arr[1] + 1));//40
	printf("(arr[1] + 1) = %p\n",(arr[1] + 1));//addr 40
	return 0;
}
