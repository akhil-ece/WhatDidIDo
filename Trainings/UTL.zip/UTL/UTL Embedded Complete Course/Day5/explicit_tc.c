#include <stdio.h>

int main()
{
	float f = 3.15;

	int var = 10;
	
	(float)var = 10.25;

	printf("f = %d\n",(int)f);

	return 0;
}
