#include <stdio.h>

int gvar = 100;
void display(void);
int main()
{

	display();
	
	printf("In file 1 gvar = %d\n",gvar);

	return 0;
}
