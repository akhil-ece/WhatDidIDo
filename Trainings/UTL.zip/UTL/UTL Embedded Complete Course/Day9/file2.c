#include <stdio.h>

extern int gvar;
void  display(void)
{

	printf("In file2 initial value of gvar = %d\n",gvar);
	gvar++;

}
