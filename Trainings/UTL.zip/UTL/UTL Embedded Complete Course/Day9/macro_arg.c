#include <stdio.h>

#define SQR(a) (a)*(a);
#define MAX(x,y) (x) > (y) ? (x) : (y)
int main()
{

	int sqr = SQR(6)
	
	printf("sqr = %d\n",sqr);
/*	printf("SQR(6) = %d\n",SQR(6));//36
	printf("SQR(3.14) = %f\n",SQR(3.14));//9.86
	printf("SQR(4+2) = %d\n",SQR(4+2));//36
*/
	printf("MAX(10,20)= %d\n",MAX(10,20));
	return 0;
}
