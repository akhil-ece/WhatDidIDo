#include <stdio.h>

#define DEBUG

	#undef DEBUG

	#ifdef DEBUG
		printf("Debug is defined\n");

	#endif

	#ifndef DEBUG
	#define DEBUG
		printf("Debug is defined now\n");
	#endif
int main()
{
	return 0;
} 
