#include <stdio.h>

int main()
{

	printf("DATE is %s\n",__DATE__);
	printf("TIME is %s\n",__TIME__);
	printf("File name is %s\n",__FILE__);
	printf("LIne number %d\n",__LINE__);
	printf("STDC is %d\n",__STDC__);

	return 0;
}
