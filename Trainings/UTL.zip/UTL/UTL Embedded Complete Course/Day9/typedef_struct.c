#include <stdio.h>

typedef struct test
{
	int var;
	char ch;
}str;
struct temp
{
	int var;
	char ch;
}temp1;

int main()
{
	str t1 = {.var = 100};

	struct test t2 = t1;
	temp1 = t1;
	printf("t2.var = %d\n",t2.var);

	return 0;
}
