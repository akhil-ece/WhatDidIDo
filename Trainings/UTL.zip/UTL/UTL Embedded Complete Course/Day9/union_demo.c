#include <stdio.h>

union u
{
	int var;
	char ch;
}u1;

int main()
{
	//union u u1;//= {100,'a'};

	u1.ch = 'a';

	printf("%d %c\n",u1.var,u1.ch);

	return 0;
}
