#include <stdio.h>
#define MAX 5

int main()
{
	int  max = 0,i = 0;

	for(i = 0; i < MAX ; i++)
		printf("Hello\n");

	return 0;
}
