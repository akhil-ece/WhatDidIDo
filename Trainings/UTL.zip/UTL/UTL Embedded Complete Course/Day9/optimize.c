#include <stdio.h>

int main()
{
	int var1 = 10,var2 = 20;
	
	if(var1 < var2)
		printf("Var1 is lesser than Var2");
	else
		printf("Var1 is greater than Var2");
		

	return 0;
}
