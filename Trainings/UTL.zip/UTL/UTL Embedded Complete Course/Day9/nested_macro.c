#include <stdio.h>

#define PI 3.14
#define AREA	PI*PI

int main()
{
	printf("AREA = %f\n",AREA);

	return 0;
}
