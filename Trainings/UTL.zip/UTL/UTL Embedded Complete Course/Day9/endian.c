#include <stdio.h>

union endian 
{
	int var;
	char ch;
}u;

int main()
{
	u.var = 0xABCDEF55;
	printf("u.var = %X\nu.ch = %x\n",u.var,u.ch);	

	return 0;
}
