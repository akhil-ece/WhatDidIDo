/* Author : Abhilash
   Date: 07-02-2019
   Purpose: First C Program
*/

#include <stdio.h>
int main()	// Entry point function
{
	printf("Hello World\n");//Library function

	return 0;
}
