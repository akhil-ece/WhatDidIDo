#include <stdio.h>

#define INTP int*

int main()
{
	typedef int* intp;

	INTP p1,p2;
	intp ptr1,ptr2;
	int a = 10,b = 20;

	p1 = &a;
	p2 = &b;
	ptr1 = &a;
	ptr2 = &b;
	return 0;
}
