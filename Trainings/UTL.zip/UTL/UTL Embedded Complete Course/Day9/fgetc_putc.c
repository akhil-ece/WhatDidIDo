#include <stdio.h>

int main()
{
	FILE* fp = NULL;
	int ch = 0;
	fp = fopen("temp2","a+");

	if(fp == NULL)
	{
		printf("fopen failed\n");
		return -1;
	}
	while((ch = fgetc(stdin)) != EOF)
		fputc(ch,fp);

	rewind(fp);
	//fclose(fp);

	/*fp = fopen("temp2","r");

	if(fp == NULL)
	{
		printf("fopen failed\n");
		return -1;
	}*/
	while((ch = fgetc(fp)) != EOF)
		fputc(ch,stdout);

	fclose(fp);
	return 0;
}
