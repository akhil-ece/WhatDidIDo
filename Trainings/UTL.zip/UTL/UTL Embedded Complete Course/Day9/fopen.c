#include <stdio.h>

int main()
{
	FILE* fp = NULL;

	fp = fopen("temp1","r");

	if(fp == NULL)
	{
		printf("fopen failed\n");
		return -1;
	}
	printf("File opened successfully\n");

	fclose(fp);
	return 0;
}
