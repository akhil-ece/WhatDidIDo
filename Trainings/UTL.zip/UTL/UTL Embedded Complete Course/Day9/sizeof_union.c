#include <stdio.h>
#pragma pack(1)
union temp
{
	int var;
	char ch;
	struct test
	{
		int var ;
		char ch;
	}t;

}u;

int main()
{
	u.t.var

	printf("sizeof(union temp) = %ld\n",sizeof(union temp));
	return 0;
}	
