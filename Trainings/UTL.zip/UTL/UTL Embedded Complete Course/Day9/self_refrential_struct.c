#include <stdio.h>
struct test
{
	void (*ptr)(void);
	int var;
	char ch;
};
struct node
{
	int data;
	struct node* n1;
};
int main()
{

	struct node first = {100,&first};

	printf("%d\n",first.n1->data);



//	printf("%d\n",node1.data);
//	printf("%d\n%c\n",node1.n1.var,node1.n1.ch);	

	return 0;
}

void display(void)
{

	printf("Display\n");
}
