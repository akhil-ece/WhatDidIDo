#include <stdio.h>

int main()
{
//	float f = 3.14 % 2;
	int var;
	char* cptr = &var;
	return 0;
}
