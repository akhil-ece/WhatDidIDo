#include <stdio.h>

int Main()
{
	printf("Linker Error\n");

	return 0;
}
