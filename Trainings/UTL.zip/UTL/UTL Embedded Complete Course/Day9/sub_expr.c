#include <stdio.h>

int main()
{
	int a = 10,b = 20,c = 0,d = 0, e= 0;

	c = a+b;
	d = a+b;
	e = a+b;

	return 0;
}
